# TP — Modulations numériques : envoyer sa date d'anniversaire

> **Support :** classeur Excel `Modulations_Numeriques_Tableau.xlsx`
> **Public :** étudiants en électronique / systèmes embarqués / télécommunications
> **Durée indicative :** 3 h à 4 h
> **Matériel :** un PC avec Microsoft Excel (2016 ou plus récent) ou LibreOffice Calc, une calculatrice, ce sujet

---

## Objectifs

À la fin de ce TP, vous serez capable de :

- convertir un message texte en train binaire (codage ASCII et BCD) ;
- regrouper les bits en symboles et placer ces symboles sur une constellation (BPSK, QPSK, 8-PSK, 16-QAM, 32-QAM) ;
- relier le nombre de bits par symbole *k* à l'ordre de modulation *M*, à la durée du message et à la sensibilité au bruit ;
- expliquer l'intérêt du codage de Gray et comparer les mappings 16-QAM de plusieurs normes (Wi-Fi, LTE/5G, DVB-T) ;
- lire un diagramme de l'œil et comprendre l'effet du filtre de mise en forme et du bruit.

---

## Rappels

### Chaîne de transmission étudiée

```
Message ──► Codage source ──► Train binaire ──► Groupes de k bits ──► Mapping (I, Q) ──► Modulation ──► s(t)
 "25/12"      ASCII / BCD        0011 0010 …          symboles             constellation      porteuse fc
```

### Bits, symboles et durées

| Grandeur | Relation |
|---|---|
| Nombre de bits par symbole | $k = \log_2 M$ |
| Durée d'un symbole | $T_s = k \cdot T_b$ |
| Débit symbole | $R_s = R_b / k$ |
| Nombre de symboles pour *N* bits | $\lceil N / k \rceil$ (on complète avec des bits de bourrage à 0) |

Dans le classeur, **le débit binaire est constant** : le temps est exprimé en durées de bit $T_b$. Un symbole dure donc $k \cdot T_b$.

### Signal modulé

Chaque symbole est associé à un point $(I, Q)$ de la constellation. Le signal émis pendant ce symbole est :

$$s(t) = I \cdot \cos(2\pi f_c t) + Q \cdot \sin(2\pi f_c t)$$

L'amplitude du signal vaut $\sqrt{I^2 + Q^2}$ et sa phase $\arctan(Q/I)$ (à ±180° près selon le quadrant).

### Normalisation

Pour comparer les modulations entre elles, les constellations sont **normalisées** de façon à ce que l'énergie moyenne par symbole vaille 1 :

$$E_s = \frac{1}{M}\sum_{m=0}^{M-1}(I_m^2 + Q_m^2) = 1$$

Les tables affichent les valeurs brutes (±1, ±3, ±5) ; le classeur calcule le facteur de normalisation.

### Codage de Gray

Dans un code de Gray, **deux points voisins de la constellation ne diffèrent que d'un seul bit**.

### Filtre en cosinus surélevé

Un filtre de mise en forme en cosinus surélevé de facteur de retombée (roll-off) $\alpha$ occupe en bande de base la bande :

$$B = \frac{(1+\alpha)\,R_s}{2}$$

### Extrait de la table ASCII

| Caractère | `/` | `0` | `1` | `2` | `3` | `4` | `5` | `6` | `7` | `8` | `9` |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Code décimal | 47 | 48 | 49 | 50 | 51 | 52 | 53 | 54 | 55 | 56 | 57 |
| Code hexadécimal | 2F | 30 | 31 | 32 | 33 | 34 | 35 | 36 | 37 | 38 | 39 |

---

## Prise en main du classeur

Le classeur ne contient **aucune macro**. Seules les **cellules jaunes** sont à modifier ; tout le reste se recalcule automatiquement.

| Onglet | Contenu |
|---|---|
| `Tableau_de_bord` | Entrées, résultats, graphes (train binaire, I/Q, s(t), constellation, diagrammes de l'œil) |
| `Bits` | Conversion caractère → code ASCII → bits (et BCD) |
| `Symboles` | Regroupement des bits, valeur décimale, I/Q bruts et normalisés, amplitude, phase |
| `Signal` | Échantillons du signal modulé |
| `Oeil` | Calcul des traces du diagramme de l'œil |
| `Constellations` | Tables de mapping de toutes les modulations et des protocoles 16-QAM |
| `Exercice` | Rappel des questions |

**Entrées du tableau de bord :**

| Cellule | Paramètre |
|---|---|
| `C4` | Modulation : BPSK, QPSK, 8-PSK, 16-QAM, 32-QAM |
| `C5` | Message à transmettre (format texte : `25/12` n'est pas converti en date) |
| `C6` | Codage source : ASCII (8 bits/caractère), BCD (4 bits/chiffre), Binaire direct (0/1) |
| `C7` | Nombre de cycles de porteuse par bit |
| `C8` | Protocole 16-QAM : Wi-Fi, LTE/5G, DVB-T, binaire naturel, personnalisé |
| `L51` | Filtre de mise en forme (diagramme de l'œil) |
| `L52` | Roll-off α |
| `L53` | Bruit σ par voie |

> ⚠️ Pour les parties 1 à 3, laissez le protocole 16-QAM sur **IEEE 802.11 (Wi-Fi)**.

---

## Partie 1 — Travail préparatoire (à la main, sans le classeur)

Ma date d'anniversaire (JJ/MM) : **`_____ / _____`**

### Question 1

Écrivez votre date d'anniversaire au format JJ/MM. Donnez le code ASCII de chaque caractère, puis la suite de bits (8 bits par caractère).

| Caractère | | | | | |
|---|---|---|---|---|---|
| Code ASCII (décimal) | | | | | |
| Code ASCII (binaire, 8 bits) | | | | | |

Train binaire complet :

```
________ ________ ________ ________ ________
```

### Question 2

Combien de bits obtenez-vous ? Combien de symboles faut-il en BPSK, QPSK, 16-QAM et 32-QAM ? Faut-il des bits de bourrage ?

Nombre de bits : **______**

| Modulation | *k* | Nombre de symboles | Bits de bourrage |
|---|---|---|---|
| BPSK | | | |
| QPSK | | | |
| 16-QAM | | | |
| 32-QAM | | | |

### Question 3

En 16-QAM, découpez votre suite de bits par paquets de 4 et placez chaque symbole sur la constellation (onglet `Constellations`, protocole Wi-Fi : `b0b1` → I, `b2b3` → Q, avec 00 → −3, 01 → −1, 11 → +1, 10 → +3).

| n° symbole | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|
| Bits | | | | | | | | | | |
| I brut | | | | | | | | | | |
| Q brut | | | | | | | | | | |

Placez le numéro de chaque symbole dans la grille :

| Q \ I | −3 | −1 | +1 | +3 |
|---|---|---|---|---|
| **+3** | | | | |
| **+1** | | | | |
| **−1** | | | | |
| **−3** | | | | |

---

## Partie 2 — Vérification avec le tableau de bord

### Question 4

Saisissez votre date dans la cellule jaune « Message » et vérifiez vos réponses 1 à 3.

☐ Question 1 correcte  ☐ Question 2 correcte  ☐ Question 3 correcte

Erreurs éventuelles et explication :

> …

### Question 5

Pour chaque modulation, relevez : *k*, *M*, nombre de symboles, durée du message. À débit binaire constant, que gagne-t-on en montant en ordre ? Que perd-on ?

| Modulation | *k* | *M* | Nombre de symboles | Durée d'un symbole (en $T_b$) | Durée du message (en $T_b$) |
|---|---|---|---|---|---|
| BPSK | | | | | |
| QPSK | | | | | |
| 8-PSK | | | | | |
| 16-QAM | | | | | |
| 32-QAM | | | | | |

Ce que l'on gagne :

> …

Ce que l'on perd :

> …

### Question 6

Sur le graphe s(t), identifiez les instants de changement de symbole. Qu'est-ce qui change : l'amplitude, la phase, les deux ? Justifiez pour BPSK, QPSK, 8-PSK et 16-QAM.

| Modulation | L'amplitude change ? | La phase change ? | Justification |
|---|---|---|---|
| BPSK | | | |
| QPSK | | | |
| 8-PSK | | | |
| 16-QAM | | | |

### Question 7

Passez en codage BCD. Combien de bits et de symboles maintenant ? Pourquoi le 16-QAM est-il particulièrement adapté ?

Nombre de bits : **______**  Nombre de symboles en 16-QAM : **______**

> …

### Question 8

Comparez la distance minimale entre deux points de la constellation normalisée en QPSK, 16-QAM et 32-QAM. Conclure sur la sensibilité au bruit.

| Modulation | Facteur de normalisation | Écart minimal brut | Distance minimale normalisée $d_{min}$ |
|---|---|---|---|
| QPSK | | | |
| 16-QAM | | | |
| 32-QAM | | | |

Conclusion :

> …

---

## Partie 3 — Pour aller plus loin

### Question 9

Codage Gray : vérifiez sur l'onglet `Constellations` que deux points voisins ne diffèrent que d'un bit en 16-QAM. Pourquoi est-ce utile ?

> …

### Question 10

Choisissez le protocole « Personnalisé » et modifiez ses cellules bleues (onglet `Constellations`, colonnes AH-AI) pour inventer votre propre mapping 16-QAM. Comparez avec « Binaire naturel » : qu'est-ce qui change dans le signal ?

Votre mapping (valeurs I et Q pour chaque groupe de bits) :

| Bits | 0000 | 0001 | 0010 | 0011 | 0100 | 0101 | 0110 | 0111 | 1000 | 1001 | 1010 | 1011 | 1100 | 1101 | 1110 | 1111 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| I | | | | | | | | | | | | | | | | |
| Q | | | | | | | | | | | | | | | | |

Observations :

> …

### Question 11

En codage « Binaire direct », construisez une suite de bits qui fait apparaître les 16 symboles du 16-QAM.

Suite de bits (64 bits) :

```
____ ____ ____ ____ ____ ____ ____ ____ ____ ____ ____ ____ ____ ____ ____ ____
```

Vérification : ☐ les 16 lignes du tableau « Mapping des symboles émis » sont en orange

---

## Partie 4 — Protocoles 16-QAM

Le choix du protocole se fait dans la cellule `C8`. Les règles de mapping et leurs références sont données dans l'onglet `Constellations` (colonnes X à AI).

| Protocole | Référence |
|---|---|
| IEEE 802.11 (Wi-Fi) | IEEE 802.11a/g/n/ac/ax (OFDM) |
| 3GPP LTE / 5G NR / HSPA | 3GPP TS 36.211 §7.1.3, TS 38.211 §5.1.3 |
| DVB-T | ETSI EN 300 744, figure 9 |

### Question 12

Envoyez votre date avec le Wi-Fi, le LTE/5G puis le DVB-T. Relevez les points (I,Q) émis. Le signal est-il le même ? Un récepteur Wi-Fi peut-il décoder un signal DVB-T ?

| n° symbole | Bits | Wi-Fi (I, Q) | LTE/5G (I, Q) | DVB-T (I, Q) |
|---|---|---|---|---|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |
| 4 | | | | |
| 5 | | | | |
| 6 | | | | |
| 7 | | | | |
| 8 | | | | |
| 9 | | | | |
| 10 | | | | |

> …

### Question 13

Vérifiez que les mappings Wi-Fi, LTE et DVB-T sont tous des codes Gray, alors que le binaire naturel ne l'est pas. Quel est l'intérêt commun des trois normes ?

| Mapping | Code de Gray ? | Exemple de deux voisins vérifiés |
|---|---|---|
| Wi-Fi | | |
| LTE / 5G | | |
| DVB-T | | |
| Binaire naturel | | |

> …

### Question 14

En DVB-T, les deux premiers bits donnent le quadrant. Pourquoi ce choix est-il utile pour la modulation hiérarchique (réception en QPSK simple) ?

> …

---

## Partie 5 — Diagramme de l'œil

Le diagramme de l'œil superpose le signal en bande de base (voie I ou Q) sur des fenêtres de 2 symboles centrées sur les instants d'échantillonnage (x = 0).

> 💡 Un message court donne peu de traces. Pour un œil plus fourni, utilisez un message plus long ou le codage « Binaire direct » (par exemple la suite construite à la question 11).

### Question 15

Avec le filtre rectangulaire puis le cosinus surélevé (α = 0,35), observez l'œil de la voie I en BPSK, QPSK et 16-QAM. Combien d'« yeux » superposés voit-on ? Relier au nombre de niveaux par voie.

| Modulation | Niveaux sur la voie I | Nombre d'yeux | Allure avec filtre rectangulaire | Allure avec cosinus surélevé |
|---|---|---|---|---|
| BPSK | | | | |
| QPSK | | | | |
| 16-QAM | | | | |

Relation entre nombre de niveaux et nombre d'yeux :

> …

### Question 16

Faites varier α de 1 à 0. Comment évoluent l'ouverture horizontale de l'œil et les dépassements ? Quel est le compromis avec la bande passante occupée ($B = (1+\alpha) \cdot R_s / 2$ en bande de base) ?

| α | Ouverture horizontale | Dépassements | Bande occupée $B$ (en fonction de $R_s$) |
|---|---|---|---|
| 1 | | | |
| 0,5 | | | |
| 0,35 | | | |
| 0 | | | |

Compromis :

> …

### Question 17

Ajoutez du bruit (σ = 0,05 puis 0,15). À partir de quelle valeur l'œil se ferme-t-il en 16-QAM ? Et en QPSK ? Conclure sur le rapport signal/bruit nécessaire.

Appuyez sur **F9** pour obtenir un nouveau tirage de bruit.

| σ | Œil 16-QAM | Œil QPSK |
|---|---|---|
| 0 | | |
| 0,05 | | |
| 0,10 | | |
| 0,15 | | |
| 0,25 | | |

Valeur de σ pour laquelle l'œil se ferme : 16-QAM **______**  QPSK **______**

Conclusion :

> …

---

## Compte rendu attendu

Rendez un compte rendu contenant :

1. les tableaux complétés et les réponses rédigées aux 17 questions ;
2. une capture du tableau de bord avec votre date en 16-QAM ;
3. une capture de la constellation pour chacun des trois protocoles de la partie 4 ;
4. une capture du diagramme de l'œil de la voie I en 16-QAM, sans bruit puis avec le bruit qui ferme l'œil ;
5. une conclusion de quelques lignes sur le compromis **débit / bande passante / robustesse au bruit**.
